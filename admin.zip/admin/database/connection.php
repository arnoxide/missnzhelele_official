<?php

$host = 'localhost:3306';
$user = 'root';
$pass = '';
$db_name = 'missnzhelele';

$conn = new MySQLI($host, $user, $pass, $db_name);
date_default_timezone_set('Africa/johannesburg');

?>
 